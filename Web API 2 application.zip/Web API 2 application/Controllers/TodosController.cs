﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TestProject.Models;

namespace TestProject.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TodosController : ControllerBase
    {
        private readonly TodosDBContext db = new TodosDBContext();


        /// <summary>
        /// LogIn Method is use for Authenticating User
        /// </summary>
        /// <param name="User Name"></param>
        /// <param name="Password"></param>
        /// <returns>Success Message User Logined Successfully or not</returns>
        [HttpGet("~/LogIn")]
        public ResponseData LogIn(LoginModel objuserlogin)
        {
            LoginModel loginModel = new LoginModel();
            ResponseData responseData = new ResponseData();
            var display = loginModel.Userloginvalues()
                .Where(m => m.UserName == objuserlogin.UserName && m.UserPassword == objuserlogin.UserPassword)
                .FirstOrDefault();

            if (display != null)
            {
                responseData.ResponseMessage = "CORRECT UserNAme and Password";
            }
            else
            {
                responseData.ResponseMessage = "INCORRECT UserName or Password";
            }

            return responseData;
        }




        /// <summary>
        /// GetTodos is Get Method it will return all Todos List
        /// </summary>
        /// <returns>List of All Todos</returns>
        [HttpGet("~/GetTodos")]
        public List<Todos> GetTodos()
        {
            return db.Todo.ToList();
        }

        /// <summary>
        /// ToDosDetails is a Post Method To get Todo against specific ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns> Rreturn Todos against provided ID if no record found empty Todos</returns>
        [HttpPost("~/ToDosDetails")]
        public Todos ToDosDetails(int? id)
        {
            if (id == null)
            {
                return new Todos();
            }
            Todos todos = db.Todo.Find(id);
            if (todos == null)
            {
                return new Todos();
            }
            return todos;
        }

        /// <summary>
        /// CreateTodos is a post method for creation of new Todos
        /// </summary>
        /// <param name="todos"></param>
        /// <returns>Return Success message on successful creation otherwise return Fails message </returns>
        [HttpPost("~/CreateTodos")]
        public ResponseData CreateTodos(Todos todos)
        {
            ResponseData respnonse = new ResponseData();
            if (ModelState.IsValid)
            {
                db.Todo.Add(todos);
                db.SaveChanges();
                respnonse.IsSuccess = true;
                respnonse.ResponseMessage = "Successfully Created Todo";
            }
            else
            {
                respnonse.IsSuccess = false;
                respnonse.ResponseMessage = "Unable To Create Todo";
            }
            return respnonse;
        }

        /// <summary>
        /// EditTodos is a post method for Updating of a Todos record
        /// </summary>
        /// <param name="todos"></param>
        /// <returns> Return success message on updating record otherwise fail message</returns>
        [HttpPost]
        public ResponseData EditTodos(Todos todos)
        {
            ResponseData respnonse = new ResponseData();
            if (ModelState.IsValid)
            {
                db.Entry(todos).State = EntityState.Modified;
                db.SaveChanges();
                respnonse.IsSuccess = true;
                respnonse.ResponseMessage = "Successfully Edited Todo";
            }
            else
            {
                respnonse.IsSuccess = false;
                respnonse.ResponseMessage = "Unable To Edited Todo";
            }
            return respnonse;
        }

        /// <summary>
        /// DeleteTodos is a post method for Deleting a Todo
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Return success message on Deleting record otherwise fail message</returns>
        [HttpPost("~/DeleteTodos")]
        public ResponseData DeleteTodos(int id)
        {
            ResponseData respnonse = new ResponseData();
            Todos todos = db.Todo.Find(id);
            db.Todo.Remove(todos);
            db.SaveChanges();

            respnonse.IsSuccess = false;
            respnonse.ResponseMessage = "Record Deleted Successfully";
            
            return respnonse;
        }
    }
}